
import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Waves } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { name: t.nav.home, path: '/' },
    { name: t.nav.about, path: '/about' },
    { name: t.nav.services, path: '/services' },
    { name: t.nav.partners, path: '/partners' },
    { name: t.nav.brands, path: '/brands' },
    { name: t.nav.contact, path: '/contact' },
  ];

  const getLinkClasses = (isActive: boolean) => 
    `text-[11px] lg:text-[12px] font-bold uppercase tracking-widest transition-all duration-300 relative group/link ${
      isActive ? 'text-corail-600' : 'text-gray-600 hover:text-corail-500'
    }`;

  return (
    <nav className={`fixed w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-md h-[70px]' : 'bg-white h-[85px]'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full h-full">
        <div className="flex justify-between items-center h-full">
          {/* Logo Placeholder */}
          <NavLink to="/" className="flex items-center space-x-3 group">
            <div className="relative flex items-center justify-center">
              <div className="w-10 h-10 bg-corail-500 rounded-xl flex items-center justify-center shadow-lg shadow-corail-500/20 group-hover:scale-110 transition-transform duration-500 overflow-hidden">
                <Waves className="text-white w-6 h-6 animate-pulse" strokeWidth={2.5} />
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 to-transparent"></div>
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-teal-500 rounded-full border-2 border-white"></div>
            </div>
            <div className="flex flex-col">
              <div className="flex items-baseline">
                <span className="text-xl lg:text-2xl font-display font-black text-gray-900 tracking-tighter leading-none group-hover:text-corail-500 transition-colors">
                  CORAIL
                </span>
                <span className="ml-1 text-sm font-display font-bold text-corail-500 tracking-tighter leading-none">
                  L'OCÉAN
                </span>
              </div>
              <span className="text-[9px] text-gray-400 font-bold tracking-[0.4em] uppercase leading-none mt-1 group-hover:text-teal-500 transition-colors">
                DISTRIBUTION
              </span>
            </div>
          </NavLink>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => (
              <NavLink
                key={link.name}
                to={link.path}
                className={({ isActive }) => getLinkClasses(isActive)}
              >
                {link.name}
                <span className={`absolute -bottom-1 left-0 w-0 h-0.5 bg-corail-500 transition-all duration-300 group-hover/link:w-full ${location.pathname === link.path ? 'w-full' : ''}`}></span>
              </NavLink>
            ))}
            
            <div className="h-4 w-px bg-gray-200 mx-2"></div>

            <div className="flex items-center space-x-3 ml-2">
               <button 
                onClick={() => setLanguage('en')}
                className={`text-[10px] font-black transition-all ${language === 'en' ? 'text-corail-600 scale-110' : 'text-gray-300 hover:text-corail-400'}`}
               >
                 EN
               </button>
               <button 
                onClick={() => setLanguage('fr')}
                className={`text-[10px] font-black transition-all ${language === 'fr' ? 'text-corail-600 scale-110' : 'text-gray-300 hover:text-corail-400'}`}
               >
                 FR
               </button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-gray-800 hover:text-corail-500 focus:outline-none transition-colors rounded-lg bg-gray-50"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Overlay */}
      <div className={`lg:hidden fixed inset-0 top-[70px] bg-white z-40 transition-all duration-500 ease-in-out transform ${isOpen ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}`}>
        <div className="px-6 py-12 space-y-6">
          {navLinks.map((link) => (
            <NavLink
              key={link.name}
              to={link.path}
              className={({ isActive }) => 
                `block text-2xl font-display font-black uppercase tracking-tight ${
                  isActive ? 'text-corail-600 translate-x-4' : 'text-gray-400 hover:text-gray-900'
                } transition-all duration-300`
              }
            >
              {link.name}
            </NavLink>
          ))}
          <div className="pt-8 border-t border-gray-100 flex items-center space-x-6">
             <button 
              onClick={() => { setLanguage('en'); setIsOpen(false); }}
              className={`text-sm font-bold tracking-widest ${language === 'en' ? 'text-corail-600' : 'text-gray-400'}`}
             >
               ENGLISH
             </button>
             <button 
              onClick={() => { setLanguage('fr'); setIsOpen(false); }}
              className={`text-sm font-bold tracking-widest ${language === 'fr' ? 'text-corail-600' : 'text-gray-400'}`}
             >
               FRANÇAIS
             </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
