
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Facebook, Linkedin, Mail, Phone, MapPin, Waves } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-slate-50 border-t border-slate-100 text-slate-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-16">
          {/* Brand Logo Placeholder */}
          <div className="col-span-1">
             <div className="flex items-center space-x-3 mb-6 group cursor-default">
                <div className="w-12 h-12 bg-corail-600 rounded-xl flex items-center justify-center shadow-lg shadow-corail-600/10">
                  <Waves className="text-white w-7 h-7" strokeWidth={2.5} />
                </div>
                <div className="flex flex-col">
                  <div className="flex items-baseline leading-none">
                    <span className="text-xl font-display font-black text-corail-900 tracking-tighter">CORAIL</span>
                    <span className="ml-1 text-sm font-display font-bold text-corail-600 tracking-tighter">L'OCÉAN</span>
                  </div>
                  <span className="text-[10px] text-teal-600 font-bold tracking-[0.3em] uppercase mt-1">Distribution</span>
                </div>
             </div>
             <p className="text-sm text-slate-500 leading-relaxed mb-6">
               {t.footer.description}
             </p>
             <div className="flex space-x-4">
               <a href="#" className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-corail-800 hover:bg-corail-600 hover:text-white hover:border-corail-600 transition-all duration-300 shadow-sm"><Facebook size={20} strokeWidth={1.5} /></a>
               <a href="#" className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-corail-800 hover:bg-corail-600 hover:text-white hover:border-corail-600 transition-all duration-300 shadow-sm"><Linkedin size={20} strokeWidth={1.5} /></a>
             </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-xs font-bold text-corail-900 uppercase tracking-widest mb-6 border-b-2 border-corail-100 w-fit pb-1">{t.footer.navigation}</h3>
            <ul className="space-y-4 text-sm font-medium">
              <li><NavLink to="/" className="text-slate-500 hover:text-corail-600 transition-colors flex items-center space-x-2"><span>{t.nav.home}</span></NavLink></li>
              <li><NavLink to="/about" className="text-slate-500 hover:text-corail-600 transition-colors flex items-center space-x-2"><span>{t.nav.about}</span></NavLink></li>
              <li><NavLink to="/partners" className="text-slate-500 hover:text-corail-600 transition-colors flex items-center space-x-2"><span>{t.nav.partners}</span></NavLink></li>
              <li><NavLink to="/brands" className="text-slate-500 hover:text-corail-600 transition-colors flex items-center space-x-2"><span>{t.nav.brands}</span></NavLink></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xs font-bold text-corail-900 uppercase tracking-widest mb-6 border-b-2 border-corail-100 w-fit pb-1">{t.footer.contact}</h3>
            <ul className="space-y-5 text-sm">
              <li className="flex items-start space-x-3 text-slate-500">
                <MapPin size={20} className="text-teal-500 mt-0.5 flex-shrink-0" strokeWidth={1.5} />
                <span className="leading-relaxed">Zone Industrielle Ouled Saleh, Bouskoura, Casablanca 20100, MA</span>
              </li>
              <li className="flex items-center space-x-3 text-slate-500">
                <Mail size={20} className="text-teal-500 flex-shrink-0" strokeWidth={1.5} />
                <a href="mailto:contact@coraildistribution.ma" className="hover:text-corail-600 transition-colors">contact@coraildistribution.ma</a>
              </li>
              <li className="flex items-center space-x-3 text-slate-500">
                <Phone size={20} className="text-teal-500 flex-shrink-0" strokeWidth={1.5} />
                <span className="hover:text-corail-600 transition-colors cursor-pointer">(+212) 5 2259 2445</span>
              </li>
            </ul>
          </div>

          {/* Brands */}
          <div>
             <h3 className="text-xs font-bold text-corail-900 uppercase tracking-widest mb-6 border-b-2 border-corail-100 w-fit pb-1">{t.footer.brands}</h3>
             <div className="flex flex-wrap gap-2.5">
                {['Colgate', 'Selpak', 'Joyful', 'Soupline', 'Cadum', 'Ajax'].map(brand => (
                  <span key={brand} className="px-3 py-1 bg-white border border-slate-200 rounded text-[10px] font-bold text-slate-500 hover:border-corail-400 hover:text-corail-600 transition-all duration-300 cursor-default uppercase tracking-tighter">
                    {brand}
                  </span>
                ))}
             </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
          <p>{t.footer.rights}</p>
          <div className="mt-4 md:mt-0 space-x-6">
            <a href="#" className="hover:text-corail-600 transition-colors">{t.footer.privacy}</a>
            <a href="#" className="hover:text-corail-600 transition-colors">{t.footer.terms}</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
