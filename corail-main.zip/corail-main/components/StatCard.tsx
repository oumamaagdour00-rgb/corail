
import React, { useState } from 'react';
import { DollarSign, Package, MapPin, Users, Warehouse, Truck, BarChart3 } from 'lucide-react';
import { Stat } from '../types';

interface StatCardProps {
  stat: Stat;
  variant?: 'overview' | 'figure';
}

const icons: Record<string, React.ElementType> = {
  DollarSign,
  Package,
  MapPin,
  Users,
  Warehouse,
  Truck,
  BarChart3
};

const StatCard: React.FC<StatCardProps> = ({ stat, variant = 'overview' }) => {
  const Icon = stat.iconName ? (icons[stat.iconName] || Package) : BarChart3;
  const [imgError, setImgError] = useState(false);

  if (variant === 'figure') {
    return (
      <div className="flex flex-col items-center text-center h-full bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 group">
        {/* Brand Logo or Icon Header */}
        <div className="h-16 w-full flex items-center justify-center mb-6">
          {stat.logoUrl && !imgError ? (
            <img 
              src={stat.logoUrl} 
              alt={stat.label} 
              className="h-full w-auto object-contain filter grayscale opacity-70 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-300"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="w-16 h-16 bg-corail-50 rounded-full flex items-center justify-center group-hover:bg-corail-100 transition-colors">
              <Icon size={32} className="text-corail-600" strokeWidth={1.5} />
            </div>
          )}
        </div>

        {/* Value */}
        <div className="mb-3 relative">
           <h3 className="text-4xl md:text-5xl font-display font-black text-corail-600 tracking-tight leading-none group-hover:scale-105 transition-transform duration-300">
             {stat.value}
           </h3>
        </div>

        {/* Label */}
        <p className="text-sm font-bold text-gray-900 uppercase tracking-widest mb-4">
          {stat.label}
        </p>

        {/* Divider */}
        <div className="w-12 h-1 bg-gray-100 rounded-full mb-4 group-hover:bg-corail-200 transition-colors"></div>

        {/* Description */}
        <p className="text-sm text-gray-500 leading-relaxed font-medium">
          {stat.description}
        </p>
      </div>
    );
  }

  // Original Overview Style
  return (
    <div className="flex flex-col items-center text-center p-6 group">
      <div className="mb-6 relative">
         <div className="absolute inset-0 bg-corail-50 rounded-full transform scale-0 group-hover:scale-100 transition-transform duration-500 ease-out"></div>
         {Icon && <Icon className="h-12 w-12 text-corail-600 relative z-10 group-hover:text-corail-500 transition-colors duration-300" strokeWidth={1} />}
      </div>
      <h3 className="text-3xl font-display font-black text-corail-900 mb-2">
        {stat.value}
      </h3>
      <p className="text-base font-bold text-gray-800 mb-1">{stat.label}</p>
      {stat.subLabel && (
        <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">{stat.subLabel}</p>
      )}
    </div>
  );
};

export default StatCard;
