import React from 'react';
import { ArrowRight } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

const Hero: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="relative h-[650px] w-full overflow-hidden mt-[80px]">
      {/* Background Image - Corporate Building */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80")' }} 
      ></div>
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-corail-600/90 via-corail-600/40 to-transparent"></div>

      {/* Content */}
      <div className="absolute inset-0 flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-extrabold text-white leading-tight mb-6 animate-fade-in-up whitespace-pre-line">
              {t.hero.title}
            </h1>
            <p className="text-lg text-white/90 mb-8 leading-relaxed max-w-lg animate-fade-in-up delay-100 font-light">
              {t.hero.subtitle}
            </p>
            
            <div className="animate-fade-in-up delay-200">
              <NavLink 
                to="/about" 
                className="inline-flex items-center justify-center px-8 py-3 bg-white text-gray-900 text-xs font-bold uppercase tracking-widest rounded-sm hover:bg-gray-100 transition-all duration-300"
              >
                {t.hero.button}
                <ArrowRight className="ml-2 h-4 w-4" />
              </NavLink>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;