
export type Language = 'en' | 'fr';

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  details: string[];
  image?: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: 'Truck' | 'Warehouse' | 'Handshake' | 'Megaphone';
}

export interface Stat {
  value: string;
  label: string;
  subLabel?: string;
  description?: string;
  iconName?: 'DollarSign' | 'Package' | 'MapPin' | 'Users' | 'Warehouse' | 'Truck';
  logoUrl?: string;
}

export interface NewsItem {
  id: string;
  date: string;
  title: string;
  excerpt: string;
  image: string;
}

export enum Brand {
  Selpak = 'Selpak',
  Joyful = 'Joyful',
  Holder = 'Holder',
  Colgate = 'Colgate',
  Soupline = 'Soupline',
  Ajax = 'Ajax',
  Cadum = 'Cadum',
  Tahiti = 'Tahiti',
  ColgatePlax = 'Colgate Plax'
}
