
import { Service, Stat, NewsItem } from './types';

interface TranslationData {
  nav: { [key: string]: string };
  hero: { title: string; subtitle: string; button: string };
  home: {
    introTitle: string;
    introSubtitle: string;
    introText: string;
    introList: string[];
    introButton: string;
    figuresTitle: string;
    brandsTitle: string;
    newsTitle: string;
    newsSubtitle: string;
    newsButton: string;
  };
  about: {
    title: string;
    subtitle: string;
    profileTitle: string;
    profileText: string[];
    visionTitle: string;
    visionText: string[];
    missionTitle: string;
    missionText: string[];
  };
  services: {
    title: string;
    subtitle: string;
    whyChooseTitle: string;
    whyChooseSubtitle: string;
    metrics: { label: string; value: string }[];
  };
  partners: {
    title: string;
    subtitle: string;
    
    // Key Retail Partners Section
    keyPartnersTitle: string;
    keyPartnersSubtitle: string;
    keyPartnersList: { title: string; text: string }[];
    keyPartnersFooter: string;

    // National Coverage Section
    coverageTitle: string;
    coverageSubtitle: string;
    coverageList: { title: string; text: string }[];
    coverageFooter: string;
    
    // Legacy stats for map visual
    mapStats: { label: string; value: string }[];
  };
  brandsPage: {
    title: string;
    subtitle: string;
    introTitle: string;
    introText: string;
    brands: {
      [key: string]: {
        description: string;
        category: string;
      }
    };
    ctaTitle: string;
    ctaSubtitle: string;
    ctaButton: string;
  };
  catalog: {
    title: string;
    subtitle: string;
    filters: string;
    results: string;
    search: string;
    searchPlaceholder: string;
    brands: string;
    categories: string;
    reset: string;
    allProducts: string;
    itemsFound: string;
    viewDetails: string;
    noProducts: string;
    noProductsText: string;
    clearFilters: string;
  };
  contact: {
    title: string;
    subtitle: string;
    getInTouch: string;
    getInTouchSubtitle: string;
    headquarters: string;
    phone: string;
    email: string;
    hours: string;
    hoursText: string[];
    formTitle: string;
    formName: string;
    formEmail: string;
    formSubject: string;
    formMessage: string;
    formButton: string;
    subjects: string[];
  };
  footer: {
    description: string;
    navigation: string;
    contact: string;
    brands: string;
    rights: string;
    privacy: string;
    terms: string;
  };
  data: {
    stats: Stat[];
    figures: Stat[];
    news: NewsItem[];
    services: Service[];
  };
}

export const translations: { [key: string]: TranslationData } = {
  en: {
    nav: {
      home: 'HOME',
      about: 'ABOUT',
      partners: 'PARTNERS',
      brands: 'BRANDS',
      contact: 'CONTACT',
      services: 'SERVICES',
      catalog: 'CATALOG'
    },
    hero: {
      title: "Essentials,\nAccessible Daily.",
      subtitle: "Corail L'Océan Distribution, an integrated industrial player in the economy of life, structured around solid pillars: Hygiene, Care, and Distribution.",
      button: "LEARN MORE"
    },
    home: {
      introTitle: "Who We Are",
      introSubtitle: "Your Trusted Partner in\nFMCG Distribution",
      introText: "Established in 2010, Corail L'Océan is a leader in the distribution of hygiene and FMCG products across Morocco. We are a key player with more than 3,000 m² of storage facilities and a robust fleet ensuring efficient logistics.",
      introList: ['Nationwide Coverage', 'Premium Brand Portfolio', 'Efficient Logistics'],
      introButton: "More about us",
      figuresTitle: "Key Figures",
      brandsTitle: "Brands We Distribute",
      newsTitle: "ACTUALITÉS",
      newsSubtitle: "Latest Updates",
      newsButton: "Read Article"
    },
    about: {
      title: "About Corail L'Océan",
      subtitle: "Distributing excellence and hygiene since 2010.",
      profileTitle: "Company Profile",
      profileText: [
        "Corail L’Océan SARL is a distribution company based in Casablanca, established in 2010. We are a key player in the FMCG and hygiene sectors, with more than 3,000 m² of storage facilities and a robust fleet ensuring efficient logistics and nationwide coverage.",
        "Our mission is to deliver high-quality products with reliable service to our partners across Morocco. We distribute major global brands including Colgate, Soupline, Tahiti, Ajax, Cadum, Selpak, and Joyful."
      ],
      visionTitle: "Our Vision",
      visionText: [
        "At Corail L’Océan, our vision is to establish ourselves as the leading distributor of hygiene and FMCG products in Morocco, setting new standards of excellence in reliability, efficiency, and service.",
        "We aspire to be the trusted partner of choice for both international and local brands seeking growth in the Moroccan market, leveraging our strong logistics network, extensive retail partnerships, and deep market expertise.",
        "Guided by a spirit of responsibility and sustainability, we aim to contribute positively to the communities we serve."
      ],
      missionTitle: "Our Mission",
      missionText: [
        "We are committed to build lasting relationships with our partners by offering excellence in service, transparency in operations, and agility in execution.",
        "By combining market expertise with a customer-first approach, we strive to create value for our suppliers, retailers, and consumers alike, while contributing to the sustainable growth of the Moroccan FMCG and hygiene sectors.",
        "Through our extensive logistics network, strong retail partnerships, and dedicated local team, we ensure that essential hygiene and FMCG products are accessible across all trade channels."
      ]
    },
    services: {
      title: "Our Services",
      subtitle: "Expertise across the entire distribution value chain.",
      whyChooseTitle: "Why Choose Corail?",
      whyChooseSubtitle: "Performance indicators that speak for themselves.",
      metrics: [
        { label: "Delivery Success", value: "98%" },
        { label: "Customer Satisfaction", value: "100%" },
        { label: "Active Vehicles", value: "45+" }
      ]
    },
    partners: {
      title: "Network & Partners",
      subtitle: "Connecting brands to every corner of the Kingdom.",
      
      keyPartnersTitle: "Key Retail Partners",
      keyPartnersSubtitle: "Trusted Relationships Across Major Wholesalers and Regional Sub Distributors",
      keyPartnersList: [
        { title: "Wholesale Partners:", text: "Key distributors in Casablanca, Rabat, Marrakech, Agadir, Fès, Tanger, Meknès and more." },
        { title: "Traditional Trade Network:", text: "Wholesalers and retailers supplying local shops and supermarkets across Morocco" }
      ],
      keyPartnersFooter: "Corail L’Océan has built long-term partnerships with leading wholesalers, ensuring wide product availability and brand presence across the country.",

      coverageTitle: "National Coverage",
      coverageSubtitle: "Nationwide Reach Through Established Distribution Network",
      coverageList: [
        { title: "Cities Covered:", text: "Casablanca, Rabat, Marrakech, Agadir, Fès, Tanger, Meknès, Oujda, Nador, Ouarzazate and others" },
        { title: "Trade Channels:", text: "Wholesale and traditional trade" },
        { title: "Logistics & Infrastructure:", text: "Central warehouse located in Casablanca & Nationwide deliveries operated through our transport fleet (+40 mixed-size vehicles) and local distribution partners." }
      ],
      coverageFooter: "Our Casablanca hub enables efficient delivery and product availability throughout Morocco.",

      mapStats: [
        { label: "Major Cities", value: "12+" },
        { label: "Points of Sale", value: "5000+" },
        { label: "Delivery Time", value: "48h" }
      ]
    },
    brandsPage: {
      title: "Distributed Brands",
      subtitle: "Proudly distributing world-class portfolios across Morocco.",
      introTitle: "Official Distribution Partner",
      introText: "We serve as the exclusive distributor for major international brands, acting as the bridge between global manufacturers and Moroccan households.",
      brands: {
        Colgate: { description: "Global leader in oral care products, offering protection and healthy smiles for the whole family.", category: "Oral Care" },
        Selpak: { description: "Premium tissue paper products known for their superior softness, strength, and absorbency.", category: "Paper Products" },
        Joyful: { description: "Advanced baby care solutions designed to provide maximum comfort and protection for infants.", category: "Baby Care" },
        Soupline: { description: "France's #1 fabric softener brand, bringing irresistible softness and long-lasting fragrance to your laundry.", category: "Laundry Care" },
        Ajax: { description: "Powerful household cleaning products that ensure a sparkling clean and fresh home environment.", category: "Home Care" },
        Cadum: { description: "Heritage brand specializing in gentle personal care products, respecting the natural balance of sensitive skin.", category: "Personal Care" },
        Tahiti: { description: "Exotic shower gels that transport you to paradise with their tropical scents and moisturizing formulas.", category: "Personal Care" },
        Holder: { description: "Reliable and eco-friendly paper solutions for everyday household needs.", category: "Paper Products" },
        ColgatePlax: { description: "Mouthwash solutions for complete oral hygiene and fresh breath confidence.", category: "Oral Care" }
      },
      ctaTitle: "Partner With Us",
      ctaSubtitle: "Looking for a reliable distribution partner for your brand in Morocco?",
      ctaButton: "Contact Our Team"
    },
    catalog: {
      title: "Product Catalog",
      subtitle: "Explore our wide range of products.",
      filters: "Filters",
      results: "Results",
      search: "Search",
      searchPlaceholder: "Search products...",
      brands: "Brands",
      categories: "Categories",
      reset: "Reset Filters",
      allProducts: "All Products",
      itemsFound: "Items Found",
      viewDetails: "View Details",
      noProducts: "No products found",
      noProductsText: "Try adjusting your search or filters to find what you're looking for.",
      clearFilters: "Clear All Filters"
    },
    contact: {
      title: "Contact Us",
      subtitle: "We are here to help and answer any question you might have.",
      getInTouch: "Get In Touch",
      getInTouchSubtitle: "Reach out to our team for partnerships, careers, or general inquiries.",
      headquarters: "Headquarters",
      phone: "Phone",
      email: "Email",
      hours: "Working Hours",
      hoursText: ["Monday - Friday: 08:30 - 18:00", "Saturday: 09:00 - 13:00", "Sunday: Closed"],
      formTitle: "Send us a Message",
      formName: "Full Name",
      formEmail: "Email Address",
      formSubject: "Subject",
      formMessage: "Message",
      formButton: "Send Message",
      subjects: ["General Inquiry", "Partnership Proposal", "Career Opportunity", "Product Information"]
    },
    footer: {
      description: "Leading distributor of hygiene and FMCG products in Morocco, setting new standards of excellence since 2010.",
      navigation: "Navigation",
      contact: "Contact",
      brands: "Top Brands",
      rights: "© 2025 Corail L'Océan Distribution. All Rights Reserved.",
      privacy: "Privacy Policy",
      terms: "Terms of Service"
    },
    data: {
      stats: [
        { value: "7 M +", label: "de foyers servis", subLabel: "quotidiennement", iconName: 'Users' },
        { value: "20 ans +", label: "de croissance continue", iconName: 'Package' },
        { value: "3,500 +", label: "Capital humain", iconName: 'DollarSign' },
      ],
      figures: [
        { 
          value: "+9.3M€", 
          label: "Colgate", 
          description: "Over MAD 102 million (€9.3 million) in annual sales with Colgate-Palmolive, reflecting a strong and lasting partnership.",
          logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Colgate_logo.svg/512px-Colgate_logo.svg.png"
        },
        { 
          value: "+5.3M€", 
          label: "Selpak", 
          description: "Over MAD 58 million (€5.3 million) in annual sales with Selpak, highlighting a solid and growing collaboration.",
          logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Selpak_logo.svg/800px-Selpak_logo.svg.png"
        },
        { 
          value: "3,000 M²", 
          label: "Storage", 
          description: "With more than 3,000 m² of storage capacity, our facilities are designed to support large-scale distribution.",
          iconName: "Warehouse"
        },
        { 
          value: "+5,000", 
          label: "Presence", 
          description: "A strong presence with 5,000+ active retail touchpoints in Casablanca and beyond.",
          iconName: "Truck"
        },
      ],
      news: [
        {
          id: '1',
          date: 'January 20, 2026',
          title: 'Corail Group accompanies a historic advance',
          excerpt: 'Through its Healthcare division, Corail Group accompanies a major step in distribution...',
          image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
        },
        {
          id: '2',
          date: 'December 15, 2025',
          title: 'Corail Group celebrates its annual partners',
          excerpt: 'Through the Foundation, Corail celebrates the excellence and commitment of its collaborators...',
          image: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
        },
        {
          id: '3',
          date: 'October 04, 2025',
          title: 'New strategic partnership signed',
          excerpt: 'Placed under the sign of innovation, this new alliance strengthens our presence...',
          image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
        }
      ],
      services: [
        { id: '1', title: 'Distribution', description: 'Comprehensive coverage of all trade channels across Morocco.', iconName: 'Truck' },
        { id: '2', title: 'Warehousing', description: 'Modern storage facilities with over 3,000 m² of capacity.', iconName: 'Warehouse' },
        { id: '3', title: 'Partnerships', description: 'Long-term strategic alliances with global hygiene brands.', iconName: 'Handshake' },
        { id: '4', title: 'Marketing', description: 'Trade marketing and brand activation support at point of sale.', iconName: 'Megaphone' }
      ]
    }
  },
  fr: {
    nav: {
      home: 'ACCUEIL',
      about: 'À PROPOS',
      partners: 'PARTENAIRES',
      brands: 'MARQUES',
      contact: 'CONTACT',
      services: 'SERVICES',
      catalog: 'CATALOGUE'
    },
    hero: {
      title: "L'essentiel, \naccessible au quotidien.",
      subtitle: "Corail L'Océan Distribution, acteur industriel intégré dans l'économie de la vie, structuré autour de piliers solides : Hygiène, Soins et Distribution.",
      button: "EN SAVOIR PLUS"
    },
    home: {
      introTitle: "Qui Sommes-Nous",
      introSubtitle: "Votre Partenaire de Confiance en\nDistribution FMCG",
      introText: "Fondée en 2010, Corail L'Océan est un leader dans la distribution de produits d'hygiène et de grande consommation au Maroc. Nous sommes un acteur clé avec plus de 3 000 m² d'installations de stockage et une flotte robuste assurant une logistique efficace.",
      introList: ['Couverture Nationale', 'Portefeuille de Marques Premium', 'Logistique Efficace'],
      introButton: "En savoir plus",
      figuresTitle: "Chiffres Clés",
      brandsTitle: "Marques Distribuées",
      newsTitle: "ACTUALITÉS",
      newsSubtitle: "Dernières Mises à Jour",
      newsButton: "Lire l'article"
    },
    about: {
      title: "À Propos de Corail L'Océan",
      subtitle: "Distributeur d'excellence et d'hygiène depuis 2010.",
      profileTitle: "Profil de l'Entreprise",
      profileText: [
        "Corail L’Océan SARL est une société de distribution basée à Casablanca, créée en 2010. Nous sommes un acteur clé dans les secteurs FMCG et de l'hygiène, avec plus de 3 000 m² d'installations de stockage et une flotte robuste assurant une logistique efficace et une couverture nationale.",
        "Notre mission est de fournir des produits de haute qualité avec un service fiable à nos partenaires à travers le Maroc. Nous distribuons de grandes marques mondiales dont Colgate, Soupline, Tahiti, Ajax, Cadum, Selpak et Joyful."
      ],
      visionTitle: "Notre Vision",
      visionText: [
        "Chez Corail L’Océan, notre vision est de nous établir comme le distributeur leader de produits d'hygiène et FMCG au Maroc, établissant de nouvelles normes d'excellence en fiabilité, efficacité et service.",
        "Nous aspirons à être le partenaire de confiance privilégié pour les marques internationales et locales cherchant à croître sur le marché marocain, en tirant parti de notre solide réseau logistique, de nos partenariats étendus et de notre expertise marché.",
        "Guidés par un esprit de responsabilité et de durabilité, nous visons à contribuer positivement aux communautés que nous servons."
      ],
      missionTitle: "Notre Mission",
      missionText: [
        "Nous nous engageons à bâtir des relations durables avec nos partenaires en offrant l'excellence dans le service, la transparence dans les opérations et l'agilité dans l'exécution.",
        "En combinant expertise marché et approche client, nous nous efforçons de créer de la valeur pour nos fournisseurs, détaillants et consommateurs, tout en contribuant à la croissance durable des secteurs FMCG et hygiène au Maroc.",
        "Grâce à notre vaste réseau logistique, nos partenariats solides et notre équipe locale dévouée, nous assurons que les produits essentiels d'hygiène et FMCG sont accessibles dans tous les canaux de vente."
      ]
    },
    services: {
      title: "Nos Services",
      subtitle: "Une expertise sur toute la chaîne de valeur de la distribution.",
      whyChooseTitle: "Pourquoi Choisir Corail ?",
      whyChooseSubtitle: "Des indicateurs de performance qui parlent d'eux-mêmes.",
      metrics: [
        { label: "Réussite de Livraison", value: "98%" },
        { label: "Satisfaction Client", value: "100%" },
        { label: "Véhicules Actifs", value: "45+" }
      ]
    },
    partners: {
      title: "Réseau & Partenaires",
      subtitle: "Connecter les marques à chaque coin du Royaume.",
      
      keyPartnersTitle: "Partenaires Clés",
      keyPartnersSubtitle: "Relations de confiance avec les principaux grossistes et sous-distributeurs régionaux",
      keyPartnersList: [
        { title: "Partenaires Grossistes :", text: "Distributeurs clés à Casablanca, Rabat, Marrakech, Agadir, Fès, Tanger, Meknès et plus." },
        { title: "Réseau Traditionnel :", text: "Grossistes et détaillants approvisionnant les magasins locaux et supermarchés à travers le Maroc" }
      ],
      keyPartnersFooter: "Corail L’Océan a établi des partenariats à long terme avec les principaux grossistes, assurant une large disponibilité des produits et une présence de marque à travers le pays.",

      coverageTitle: "Couverture Nationale",
      coverageSubtitle: "Portée nationale grâce à un réseau de distribution établi",
      coverageList: [
        { title: "Villes couvertes :", text: "Casablanca, Rabat, Marrakech, Agadir, Fès, Tanger, Meknès, Oujda, Nador, Ouarzazate et autres" },
        { title: "Canaux commerciaux :", text: "Gros et commerce traditionnel" },
        { title: "Logistique & Infrastructure :", text: "Entrepôt central situé à Casablanca & livraisons nationales opérées via notre flotte (+40 véhicules) et partenaires locaux." }
      ],
      coverageFooter: "Notre hub de Casablanca permet une livraison efficace et une disponibilité des produits partout au Maroc.",

      mapStats: [
        { label: "Grandes Villes", value: "12+" },
        { label: "Points de Vente", value: "5000+" },
        { label: "Délai de Livraison", value: "48h" }
      ]
    },
    brandsPage: {
      title: "Marques Distribuées",
      subtitle: "Distribution de portefeuilles de classe mondiale à travers le Maroc.",
      introTitle: "Partenaire de Distribution Officiel",
      introText: "Nous servons de distributeur exclusif pour de grandes marques internationales, servant de pont entre les fabricants mondiaux et les foyers marocains.",
      brands: {
        Colgate: { description: "Leader mondial des produits d'hygiène bucco-dentaire, offrant protection et sourires sains pour toute la famille.", category: "Hygiène Bucco-Dentaire" },
        Selpak: { description: "Produits en papier de qualité supérieure reconnus pour leur douceur, leur résistance et leur absorption exceptionnelles.", category: "Produits Papier" },
        Joyful: { description: "Solutions de soins pour bébés avancées conçues pour offrir un confort et une protection maximaux aux nourrissons.", category: "Soins Bébé" },
        Soupline: { description: "Marque n°1 d'adoucissant en France, apportant une douceur irrésistible et un parfum durable à votre linge.", category: "Soin du Linge" },
        Ajax: { description: "Produits de nettoyage ménager puissants qui assurent un environnement domestique étincelant de propreté et de fraîcheur.", category: "Entretien Maison" },
        Cadum: { description: "Marque patrimoniale spécialisée dans les produits de soins personnels doux, respectant l'équilibre naturel des peaux sensibles.", category: "Soins Personnels" },
        Tahiti: { description: "Gels douche exotiques qui vous transportent au paradis avec leurs parfums tropicaux et formules hydratantes.", category: "Soins Personnels" },
        Holder: { description: "Reliable and eco-friendly paper solutions for everyday household needs.", category: "Produits Papier" },
        ColgatePlax: { description: "Solutions de bain de bouche pour une hygiène bucco-dentaire complète et une confiance en son haleine.", category: "Hygiène Bucco-Dentaire" }
      },
      ctaTitle: "Devenez Partenaire",
      ctaSubtitle: "Vous cherchez un partenaire de distribution fiable pour votre marque au Maroc ?",
      ctaButton: "Contactez notre équipe"
    },
    catalog: {
      title: "Catalogue Produits",
      subtitle: "Explorez notre large gamme de produits.",
      filters: "Filtres",
      results: "Résultats",
      search: "Recherche",
      searchPlaceholder: "Rechercher des produits...",
      brands: "Marques",
      categories: "Catégories",
      reset: "Réinitialiser",
      allProducts: "Tous les produits",
      itemsFound: "Articles trouvés",
      viewDetails: "Voir Détails",
      noProducts: "Aucun produit trouvé",
      noProductsText: "Essayez d'ajuster votre recherche ou vos filtres pour trouver ce que vous cherchez.",
      clearFilters: "Effacer tous les filtres"
    },
    contact: {
      title: "Contactez-Nous",
      subtitle: "Nous sommes là pour aider et répondre à toutes vos questions.",
      getInTouch: "Entrer en Contact",
      getInTouchSubtitle: "Contactez notre équipe pour partenariats, carrières ou demandes générales.",
      headquarters: "Siège Social",
      phone: "Téléphone",
      email: "Email",
      hours: "Heures d'Ouverture",
      hoursText: ["Lundi - Vendredi : 08:30 - 18:00", "Samedi : 09:00 - 13:00", "Dimanche : Fermé"],
      formTitle: "Envoyez-nous un message",
      formName: "Nom Complet",
      formEmail: "Adresse Email",
      formSubject: "Sujet",
      formMessage: "Message",
      formButton: "Envoyer le Message",
      subjects: ["Demande Générale", "Proposition de Partenariat", "Opportunité de Carrière", "Information Produit"]
    },
    footer: {
      description: "Distributeur leader de produits d'hygiène et FMCG au Maroc, établissant de nouveaux standards d'excellence depuis 2010.",
      navigation: "Navigation",
      contact: "Contact",
      brands: "Top Marques",
      rights: "© 2025 Corail L'Océan Distribution. Tous droits réservés.",
      privacy: "Politique de Confidentialité",
      terms: "Conditions d'Utilisation"
    },
    data: {
      stats: [
        { value: "7 M +", label: "de foyers servis", subLabel: "quotidiennement", iconName: 'Users' },
        { value: "20 ans +", label: "de croissance continue", iconName: 'Package' },
        { value: "3,500 +", label: "Capital humain", iconName: 'DollarSign' },
      ],
      figures: [
        { 
          value: "+9.3M€", 
          label: "Colgate", 
          description: "Plus de 102 millions de MAD (9,3 millions d'euros) de ventes annuelles avec Colgate-Palmolive, reflétant un partenariat solide.",
          logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Colgate_logo.svg/512px-Colgate_logo.svg.png"
        },
        { 
          value: "+5.3M€", 
          label: "Selpak", 
          description: "Plus de 58 millions de MAD (5,3 millions d'euros) de ventes annuelles avec Selpak, soulignant une collaboration solide.",
          logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Selpak_logo.svg/800px-Selpak_logo.svg.png"
        },
        { 
          value: "3,000 M²", 
          label: "Stockage", 
          description: "Avec plus de 3 000 m² de capacité de stockage, nos installations sont conçues pour soutenir une distribution à grande échelle.",
          iconName: "Warehouse"
        },
        { 
          value: "+5,000", 
          label: "Présence", 
          description: "Une forte présence avec plus de 5 000 points de vente actifs à Casablanca et au-delà.",
          iconName: "Truck"
        },
      ],
      news: [
        {
          id: '1',
          date: 'Janvier 20, 2026',
          title: 'Corail Group accompagne une avancée historique',
          excerpt: 'À travers son pôle Healthcare, Corail Group accompagne une étape majeure dans la distribution...',
          image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
        },
        {
          id: '2',
          date: 'Décembre 15, 2025',
          title: 'Corail Group célèbre ses partenaires annuels',
          excerpt: 'À travers la Fondation, Corail célèbre l\'excellence et l\'engagement de ses collaborateurs...',
          image: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
        },
        {
          id: '3',
          date: 'Octobre 04, 2025',
          title: 'Nouveau partenariat stratégique signé',
          excerpt: 'Placée sous le signe de l\'innovation, cette nouvelle alliance renforce notre présence...',
          image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
        }
      ],
      services: [
        { id: '1', title: 'Distribution', description: 'Couverture complète de tous les canaux de vente à travers le Maroc.', iconName: 'Truck' },
        { id: '2', title: 'Entreposage', description: 'Installations de stockage modernes avec plus de 3 000 m² de capacité.', iconName: 'Warehouse' },
        { id: '3', title: 'Partenariats', description: 'Alliances stratégiques à long terme avec des marques d\'hygiène mondiales.', iconName: 'Handshake' },
        { id: '4', title: 'Marketing', description: 'Soutien au marketing commercial et à l\'activation de la marque au point de vente.', iconName: 'Megaphone' }
      ]
    }
  }
};
