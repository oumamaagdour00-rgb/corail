import { Brand, Product } from './types';

export const COMPANY_NAME = "Corail L'Océan Distribution";
export const FOUNDED_YEAR = 2010;
export const LOCATION = "Casablanca, Morocco";

export const BRAND_DETAILS = [
  {
    id: Brand.Colgate,
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Colgate_logo.svg/512px-Colgate_logo.svg.png",
    color: "border-red-600"
  },
  {
    id: Brand.Selpak,
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Selpak_logo.svg/800px-Selpak_logo.svg.png",
    color: "border-blue-800"
  },
  {
    id: Brand.Joyful,
    logoUrl: null,
    color: "border-purple-400"
  },
  {
    id: Brand.Soupline,
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Soupline_logo.svg/2560px-Soupline_logo.svg.png",
    color: "border-blue-400"
  },
  {
    id: Brand.Ajax,
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Ajax_logo.svg/1200px-Ajax_logo.svg.png",
    color: "border-blue-600"
  },
  {
    id: Brand.Cadum,
    logoUrl: null,
    color: "border-pink-300"
  },
  {
    id: Brand.Tahiti,
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Tahiti_Douche_Logo.svg/1200px-Tahiti_Douche_Logo.svg.png",
    color: "border-green-500"
  },
  {
    id: Brand.ColgatePlax,
    logoUrl: null,
    color: "border-red-500"
  },
  {
    id: Brand.Holder,
    logoUrl: null,
    color: "border-teal-500"
  }
];

export const PRODUCTS: Product[] = [
  // Selpak
  { id: 's1', brand: Brand.Selpak, name: 'Selpak 9 Rolls', category: 'Paper', details: ['Toilet Paper', 'Super Soft', '3 Ply'] },
  { id: 's2', brand: Brand.Selpak, name: 'Selpak 32 Rolls', category: 'Paper', details: ['Toilet Paper', 'Super Soft', '3 Ply'] },
  { id: 's3', brand: Brand.Selpak, name: 'Selpak 24 Rolls', category: 'Paper', details: ['Toilet Paper', 'Super Soft', '3 Ply'] },
  { id: 's4', brand: Brand.Selpak, name: 'Selpak 12 Rolls', category: 'Paper', details: ['Toilet Paper', 'Super Soft', '3 Ply'] },
  { id: 's5', brand: Brand.Selpak, name: 'Selpak 16 Rolls', category: 'Paper', details: ['Toilet Paper', 'Super Soft', '3 Ply'] },
  { id: 's6', brand: Brand.Selpak, name: 'Selpak 4 Rolls', category: 'Paper', details: ['Toilet Paper', 'Super Soft', '3 Ply'] },
  { id: 's7', brand: Brand.Selpak, name: 'Selpak 550', category: 'Tissues', details: ['Soft & Strong', '275 x 2 Ply'] },
  { id: 's8', brand: Brand.Selpak, name: 'Selpak 300', category: 'Tissues', details: ['Soft & Strong', '150 x 2 Ply'] },
  { id: 's9', brand: Brand.Selpak, name: 'Selpak Box 200', category: 'Tissues', details: ['Soft & Strong', '200 Sheets'] },
  { id: 's10', brand: Brand.Selpak, name: 'Selpak Box 150', category: 'Tissues', details: ['Soft & Strong', '150 Sheets'] },
  { id: 's11', brand: Brand.Selpak, name: 'Cube Tissue Box', category: 'Tissues', details: ['Soft & Strong', '3 Ply', '48 Sheets'] },
  { id: 's12', brand: Brand.Selpak, name: 'Hanky Classic', category: 'Tissues', details: ['Pocket Hanky', 'Pack of 10'] },
  { id: 's13', brand: Brand.Selpak, name: 'Selpak Box 70', category: 'Tissues', details: ['Soft & Strong', '3 Ply', '70 Sheets'] },
  { id: 's14', brand: Brand.Selpak, name: 'Selpak Box 50', category: 'Tissues', details: ['Soft & Strong', '3 Ply', '50 Sheets'] },
  { id: 's15', brand: Brand.Selpak, name: 'Selpak 3', category: 'Paper', details: ['Kitchen Paper Towel', 'Super Absorbent'] },
  { id: 's16', brand: Brand.Selpak, name: 'Selpak Mega 1=6', category: 'Paper', details: ['Kitchen Paper Towel', 'Super Absorbent'] },
  { id: 's17', brand: Brand.Selpak, name: 'Selpak Maxi 2=6', category: 'Paper', details: ['Kitchen Paper Towel', 'Super Absorbent'] },
  { id: 's18', brand: Brand.Selpak, name: 'Napkin', category: 'Paper', details: ['Comfort', '80 Pieces'] },

  // Joyful
  { id: 'j1', brand: Brand.Joyful, name: 'Joyful Mini 2', category: 'Baby Care', details: ['3-6 KG', '64 Pieces'] },
  { id: 'j2', brand: Brand.Joyful, name: 'Joyful Midi 3', category: 'Baby Care', details: ['4-9 KG', '52 Pieces'] },
  { id: 'j3', brand: Brand.Joyful, name: 'Joyful Maxi 4', category: 'Baby Care', details: ['7-18 KG', '44 Pieces'] },
  { id: 'j4', brand: Brand.Joyful, name: 'Joyful Junior 5', category: 'Baby Care', details: ['11-25 KG', '36 Pieces'] },
  { id: 'j5', brand: Brand.Joyful, name: 'Joyful XL 6', category: 'Baby Care', details: ['16+ KG', '32 Pieces'] },
  
  // Holder
  { id: 'h1', brand: Brand.Holder, name: 'Holder 12 Rolls', category: 'Paper', details: ['Toilet Paper', 'Eco Friendly'] },
  { id: 'h2', brand: Brand.Holder, name: 'Holder 6 Rolls', category: 'Paper', details: ['Kitchen Towel', 'Strong'] },

  // Colgate
  { id: 'c1', brand: Brand.Colgate, name: 'Colgate Total', category: 'Oral Care', details: ['Toothpaste', '12 Hour Protection'] },
  { id: 'c2', brand: Brand.Colgate, name: 'Colgate Max Fresh', category: 'Oral Care', details: ['Toothpaste', 'Cooling Crystals'] },
  { id: 'c3', brand: Brand.Colgate, name: 'Colgate 360', category: 'Oral Care', details: ['Toothbrush', 'Medium'] },
  
  // Soupline
  { id: 'sp1', brand: Brand.Soupline, name: 'Soupline Grand Air', category: 'Laundry', details: ['Fabric Softener', '3L'] },
  { id: 'sp2', brand: Brand.Soupline, name: 'Soupline Lavande', category: 'Laundry', details: ['Fabric Softener', '3L'] },
];