
import React from 'react';
import Hero from '../components/Hero';
import StatCard from '../components/StatCard';
import SectionTitle from '../components/SectionTitle';
import { NavLink } from 'react-router-dom';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { BRAND_DETAILS } from '../constants';

const Home: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <div className="flex flex-col w-full">
      <Hero />

      {/* Brief Intro */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
             <div className="relative">
                <div className="absolute -top-4 -left-4 w-24 h-24 bg-corail-50 rounded-full mix-blend-multiply filter blur-xl opacity-70"></div>
                <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-slate-100 rounded-full mix-blend-multiply filter blur-xl opacity-70"></div>
                
                <img 
                  src="https://images.unsplash.com/photo-1580674684081-7617fbf3d745?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                  alt="Warehouse" 
                  className="relative rounded-2xl shadow-2xl w-full h-auto object-cover"
                />
                
                <div className="absolute -bottom-8 -right-8 bg-white p-6 rounded-xl shadow-xl border border-gray-50 hidden md:block">
                  <div className="flex items-center space-x-4">
                    <div className="bg-corail-500 text-white p-3 rounded-full font-bold">15+</div>
                    <div className="text-sm font-semibold text-gray-800">Years of<br/>Excellence</div>
                  </div>
                </div>
             </div>
             
             <div>
                <span className="text-corail-500 font-bold tracking-widest text-xs uppercase mb-2 block">{t.home.introTitle}</span>
                <h2 className="text-3xl md:text-4xl font-display font-black text-corail-900 mb-6 leading-tight whitespace-pre-line">
                  {t.home.introSubtitle}
                </h2>
                <p className="text-gray-600 leading-relaxed mb-6 text-lg">
                  {t.home.introText}
                </p>
                
                <ul className="space-y-4 mb-8">
                  {t.home.introList.map((item) => (
                    <li key={item} className="flex items-center space-x-3 text-gray-700 font-medium">
                      <CheckCircle2 className="text-corail-500 h-5 w-5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                <NavLink to="/about" className="text-white bg-corail-900 hover:bg-corail-800 px-10 py-4 rounded-sm font-bold text-xs uppercase tracking-wider inline-flex items-center group transition-colors shadow-lg">
                  {t.home.introButton}
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </NavLink>
             </div>
          </div>
        </div>
      </section>

      {/* Key Figures */}
      <section className="py-24 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle 
            title={t.home.figuresTitle} 
            subtitle={language === 'en' ? "Performance Indicators" : "Indicateurs de Performance"}
            alignment="center" 
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {t.data.figures.map((figure, idx) => (
              <StatCard key={idx} stat={figure} variant="figure" />
            ))}
          </div>
        </div>
      </section>

      {/* Brands Scrolling (Cards Style) */}
      <section className="py-24 bg-corail-900 overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16 relative z-10">
          <h2 className="text-4xl font-display font-bold text-white mb-4">{t.home.brandsTitle}</h2>
          <div className="h-1 w-24 bg-corail-600 mx-auto rounded-full"></div>
        </div>
        
        {/* Background texture overlay */}
        <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at center, white 1px, transparent 1px)', backgroundSize: '30px 30px' }}></div>

        <div className="relative flex overflow-x-hidden group no-scrollbar">
          <div className="animate-marquee whitespace-nowrap flex space-x-8 items-center pl-4">
            {[...BRAND_DETAILS, ...BRAND_DETAILS, ...BRAND_DETAILS].map((brand, i) => (
              <div 
                key={`${brand.id}-${i}`} 
                className="w-72 h-44 bg-white rounded-xl shadow-xl flex-shrink-0 flex items-center justify-center p-8 hover:scale-105 transition-transform duration-300 cursor-pointer"
              >
                 {brand.logoUrl ? (
                   <img src={brand.logoUrl} alt={brand.id} className="max-h-full max-w-full object-contain filter hover:brightness-110 transition-all" />
                 ) : (
                   <span className="text-2xl font-display font-black text-gray-800 uppercase tracking-tighter">
                     {brand.id}
                   </span>
                 )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
