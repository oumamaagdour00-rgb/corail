import React from 'react';
import { Truck, Warehouse, Handshake, Megaphone, CheckCircle2, ArrowRight } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Services: React.FC = () => {
  const { t } = useLanguage();

  const serviceImages: Record<string, string> = {
    '1': 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80', // Distribution
    '2': 'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80', // Warehousing
    '3': 'https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80', // Partnerships
    '4': 'https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80', // Marketing
  };

  const icons: Record<string, React.ElementType> = {
    Truck,
    Warehouse,
    Handshake,
    Megaphone
  };

  return (
    <div className="pt-20 min-h-screen bg-white font-sans">
        {/* Hero Section */}
        <div className="relative h-[500px] w-full bg-corail-900 overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')] bg-cover bg-center opacity-20"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-corail-900/90 via-corail-800/80 to-transparent"></div>
            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
                <span className="inline-block py-1 px-3 rounded bg-teal-500/20 text-teal-300 text-xs font-bold tracking-[0.2em] uppercase w-fit mb-6 border border-teal-500/30">
                    Our Expertise
                </span>
                <h1 className="text-4xl md:text-6xl font-display font-black text-white mb-6 max-w-4xl leading-tight">
                    {t.services.title}
                </h1>
                <p className="text-xl text-gray-200 max-w-2xl font-light leading-relaxed">
                    {t.services.subtitle}
                </p>
            </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Main Service Pillars */}
            <div className="py-24 space-y-32">
                {t.data.services.map((service, index) => {
                    const Icon = icons[service.iconName] || Truck;
                    return (
                        <div key={service.id} className={`flex flex-col ${index % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-12 lg:gap-20 items-center group`}>
                            {/* Image Visual */}
                            <div className="w-full lg:w-1/2">
                                <div className="relative">
                                    <div className={`absolute -inset-4 bg-gradient-to-r ${index % 2 === 0 ? 'from-corail-100 to-transparent' : 'from-teal-100 to-transparent'} rounded-3xl opacity-50 transform rotate-3 group-hover:rotate-6 transition-transform duration-500`}></div>
                                    <div className="relative h-[400px] w-full rounded-2xl overflow-hidden shadow-lg">
                                        <img 
                                            src={serviceImages[service.id]} 
                                            alt={service.title} 
                                            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-in-out"
                                        />
                                        <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-md p-4 rounded-xl shadow-lg">
                                            <Icon className="h-8 w-8 text-corail-600" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Text Content */}
                            <div className="w-full lg:w-1/2">
                                <div className="flex items-center space-x-2 mb-4">
                                    <span className="h-px w-8 bg-corail-500"></span>
                                    <span className="text-corail-600 font-bold uppercase tracking-widest text-xs">Service 0{index + 1}</span>
                                </div>
                                <h3 className="text-4xl font-display font-bold text-gray-900 mb-6">{service.title}</h3>
                                <p className="text-xl text-gray-600 leading-relaxed mb-8 font-light">
                                    {service.description}
                                </p>
                                
                                <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 mb-8">
                                    <h4 className="font-bold text-gray-900 mb-4 flex items-center">
                                        Key Capabilities
                                    </h4>
                                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        {['Process Optimization', 'Real-time Tracking', 'Cost Efficiency', 'Scalable Solutions'].map((item, i) => (
                                            <li key={i} className="flex items-center space-x-2 text-sm text-gray-600">
                                                <CheckCircle2 size={16} className="text-teal-500" />
                                                <span>{item}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>

                                <button className="group flex items-center text-corail-700 font-bold uppercase tracking-wider text-xs hover:text-corail-900 transition-colors">
                                    Learn more about {service.title}
                                    <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
                                </button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    </div>
  );
};

export default Services;