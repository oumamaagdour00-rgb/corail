
import React from 'react';
import SectionTitle from '../components/SectionTitle';
import { Handshake, MapPin } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Partners: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-24 pb-16 min-h-screen bg-white">
      {/* Header */}
      <div className="bg-corail-900 text-white py-16 mb-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">{t.partners.title}</h1>
          <p className="text-xl text-teal-100 max-w-2xl mx-auto">
            {t.partners.subtitle}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-32">
        
        {/* Section 1: Key Retail Partners */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            <div>
              <div className="flex items-center space-x-4 mb-6">
                 <h2 className="text-3xl md:text-4xl font-display font-bold text-corail-900">
                   {t.partners.keyPartnersTitle}
                 </h2>
                 <Handshake className="text-corail-600 h-10 w-10 stroke-1" />
              </div>
              <p className="text-lg font-semibold text-corail-900 mb-8 border-l-4 border-corail-500 pl-4">
                 {t.partners.keyPartnersSubtitle}
              </p>

              <ul className="space-y-6 mb-10">
                 {t.partners.keyPartnersList.map((item, idx) => (
                    <li key={idx} className="flex items-start">
                       <span className="flex-shrink-0 h-2 w-2 mt-2.5 bg-corail-500 rounded-full mr-4"></span>
                       <span className="text-gray-700 leading-relaxed">
                          <strong className="text-gray-900">{item.title}</strong> {item.text}
                       </span>
                    </li>
                 ))}
              </ul>
              
              <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-teal-500 text-gray-600 italic">
                 {t.partners.keyPartnersFooter}
              </div>
            </div>

            {/* Visual for Retail Partners */}
            <div className="relative h-full min-h-[400px] w-full bg-gray-100 rounded-3xl overflow-hidden shadow-xl group">
               <img 
                 src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                 alt="Retail Partnership" 
                 className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-corail-900/60 to-transparent flex flex-col justify-end p-8">
                  <div className="text-white font-display font-bold text-2xl mb-2">Build Together</div>
                  <div className="w-12 h-1 bg-teal-400"></div>
               </div>
            </div>
        </div>


        {/* Section 2: National Coverage */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Visual for National Coverage - Replaced Stats with Image */}
            <div className="order-2 lg:order-1 relative h-full min-h-[400px] w-full bg-gray-100 rounded-3xl overflow-hidden shadow-xl group">
               <img 
                 src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                 alt="National Logistics" 
                 className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-corail-900/60 to-transparent flex flex-col justify-end p-8">
                  <div className="text-white font-display font-bold text-2xl mb-2">Logistics Excellence</div>
                  <div className="w-12 h-1 bg-teal-400"></div>
               </div>
            </div>

            <div className="order-1 lg:order-2">
              <div className="flex items-center space-x-4 mb-6">
                 <h2 className="text-3xl md:text-4xl font-display font-bold text-corail-900">
                   {t.partners.coverageTitle}
                 </h2>
                 <MapPin className="text-corail-600 h-10 w-10 stroke-1" />
              </div>
              
              <p className="text-lg font-semibold text-corail-900 mb-8 border-l-4 border-corail-500 pl-4">
                 {t.partners.coverageSubtitle}
              </p>

              <ul className="space-y-6 mb-10">
                 {t.partners.coverageList.map((item, idx) => (
                    <li key={idx} className="flex items-start">
                       <span className="flex-shrink-0 h-2 w-2 mt-2.5 bg-corail-500 rounded-full mr-4"></span>
                       <span className="text-gray-700 leading-relaxed">
                          <strong className="text-gray-900">{item.title}</strong> {item.text}
                       </span>
                    </li>
                 ))}
              </ul>
              
              <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-teal-500 text-gray-600 italic">
                 {t.partners.coverageFooter}
              </div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default Partners;
