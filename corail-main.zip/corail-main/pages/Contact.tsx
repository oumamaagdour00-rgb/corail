import React from 'react';
import SectionTitle from '../components/SectionTitle';
import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Contact: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-24 pb-16 min-h-screen bg-white">
      {/* Header */}
      <div className="bg-corail-900 text-white py-16 mb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">{t.contact.title}</h1>
          <p className="text-xl text-teal-100 max-w-2xl mx-auto">
            {t.contact.subtitle}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Info */}
          <div>
            <SectionTitle title={t.contact.getInTouch} subtitle={t.contact.getInTouchSubtitle} />
            
            <div className="space-y-8 mt-8">
              <div className="flex items-start space-x-4">
                <div className="bg-teal-50 p-3 rounded-lg">
                  <MapPin className="h-6 w-6 text-teal-600" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-900 mb-1">{t.contact.headquarters}</h4>
                  <p className="text-gray-600 leading-relaxed">
                    Zone Industrielle Ouled Saleh,<br />
                    Bouskoura, Casablanca 20100,<br />
                    Morocco
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-teal-50 p-3 rounded-lg">
                  <Phone className="h-6 w-6 text-teal-600" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-900 mb-1">{t.contact.phone}</h4>
                  <p className="text-gray-600">(+212) 5 2259 2445</p>
                  <p className="text-gray-500 text-sm mt-1">{t.contact.hoursText[0]}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-teal-50 p-3 rounded-lg">
                  <Mail className="h-6 w-6 text-teal-600" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-900 mb-1">{t.contact.email}</h4>
                  <a href="mailto:contact@coraildistribution.ma" className="text-teal-600 font-semibold hover:underline">
                    contact@coraildistribution.ma
                  </a>
                  <p className="text-gray-500 text-sm mt-1">We'll respond within 24 hours.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-teal-50 p-3 rounded-lg">
                  <Clock className="h-6 w-6 text-teal-600" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-900 mb-1">{t.contact.hours}</h4>
                  {t.contact.hoursText.map((hour, idx) => (
                    <p key={idx} className="text-gray-600">{hour}</p>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100 shadow-lg">
            <h3 className="text-2xl font-bold text-corail-900 mb-6">{t.contact.formTitle}</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">{t.contact.formName}</label>
                  <input type="text" id="name" className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none transition-all" placeholder="John Doe" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">{t.contact.formEmail}</label>
                  <input type="email" id="email" className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none transition-all" placeholder="john@example.com" />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">{t.contact.formSubject}</label>
                <select id="subject" className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none transition-all bg-white">
                  {t.contact.subjects.map(subject => (
                    <option key={subject}>{subject}</option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">{t.contact.formMessage}</label>
                <textarea id="message" rows={4} className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none transition-all resize-none" placeholder="..."></textarea>
              </div>

              <button type="button" className="w-full bg-corail-900 hover:bg-teal-500 text-white font-bold py-4 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center space-x-2">
                <span>{t.contact.formButton}</span>
                <Send size={18} />
              </button>
            </form>
          </div>
        </div>

        {/* Map */}
        <div className="mt-20 rounded-2xl overflow-hidden shadow-xl border border-gray-200 h-[400px]">
           <iframe 
             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3326.8920367232!2d-7.6534277!3d33.5049363!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xda62d6600000001%3A0x0!2zMzPCsDMwJzE3LjgiTiA3wrAzOSwxMi4zIlc!5e0!3m2!1sen!2sma!4v1620000000000!5m2!1sen!2sma" 
             width="100%" 
             height="100%" 
             style={{ border: 0 }} 
             allowFullScreen 
             loading="lazy"
           ></iframe>
        </div>
      </div>
    </div>
  );
};

export default Contact;