
import React from 'react';
import { ArrowRight } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { BRAND_DETAILS } from '../constants';

const Brands: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-24 pb-16 min-h-screen bg-white">
      {/* Simplified Header */}
      <div className="bg-white text-center py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-display font-black text-gray-900 mb-6 tracking-tight">
            {t.brandsPage.title}
          </h1>
          <p className="text-xl text-gray-500 font-light max-w-2xl mx-auto leading-relaxed">
            {t.brandsPage.subtitle}
          </p>
          <div className="mt-8 flex justify-center space-x-2">
             <div className="h-1 w-12 bg-corail-500 rounded-full"></div>
             <div className="h-1 w-2 bg-gray-200 rounded-full"></div>
             <div className="h-1 w-2 bg-gray-200 rounded-full"></div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Minimal Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-px bg-gray-200 border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          {BRAND_DETAILS.map((brand) => {
             return (
               <div key={brand.id} className="bg-white p-8 md:p-12 flex flex-col items-center justify-center hover:bg-gray-50 transition-colors duration-300 group h-48 md:h-64 relative">
                  
                  {brand.logoUrl ? (
                    <img 
                      src={brand.logoUrl} 
                      alt={brand.id} 
                      className="max-h-16 md:max-h-24 max-w-full object-contain filter grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:scale-110"
                    />
                  ) : (
                    <div className="text-center">
                       <span className="text-xl font-display font-bold text-gray-300 group-hover:text-corail-600 transition-colors">{brand.id}</span>
                    </div>
                  )}

                  {/* Brand Name Tooltip-ish */}
                  <div className="absolute bottom-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-xs font-bold text-gray-400 uppercase tracking-widest pointer-events-none">
                     {brand.id}
                  </div>
               </div>
             );
          })}
        </div>

        {/* CTA Section */}
        <div className="mt-24 mb-12 text-center">
           <div className="max-w-2xl mx-auto">
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">{t.brandsPage.ctaTitle}</h2>
              <p className="text-gray-500 mb-8">{t.brandsPage.ctaSubtitle}</p>
              <NavLink 
                to="/partners" 
                className="inline-flex items-center px-8 py-3 bg-corail-900 text-white font-bold uppercase tracking-widest text-xs rounded hover:bg-corail-800 transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5"
              >
                {t.brandsPage.ctaButton}
                <ArrowRight className="ml-2 h-4 w-4" />
              </NavLink>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Brands;
