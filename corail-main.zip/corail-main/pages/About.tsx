import React from 'react';
import SectionTitle from '../components/SectionTitle';
import { useLanguage } from '../contexts/LanguageContext';

const About: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-24 pb-16">
      {/* Header */}
      <div className="bg-corail-900 text-white py-20 mb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">{t.about.title}</h1>
          <p className="text-xl text-teal-100 max-w-2xl mx-auto">
            {t.about.subtitle}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
        
        {/* Company Profile */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
           <div>
             <SectionTitle title={t.about.profileTitle} />
             <div className="prose prose-lg text-gray-600">
               {t.about.profileText.map((paragraph, idx) => (
                 <p key={idx} className="mb-4">{paragraph}</p>
               ))}
             </div>
           </div>
           <div className="rounded-2xl overflow-hidden shadow-2xl">
             <img 
               src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
               alt="Headquarters" 
               className="w-full h-full object-cover"
             />
           </div>
        </div>

        {/* Vision */}
        <div className="bg-corail-50 rounded-3xl p-8 md:p-16">
          <SectionTitle title={t.about.visionTitle} alignment="center" />
          <div className="text-center max-w-4xl mx-auto text-lg text-gray-700 leading-relaxed space-y-6">
            {t.about.visionText.map((paragraph, idx) => (
              <p key={idx} className={idx === t.about.visionText.length - 1 ? "font-semibold text-corail-800" : ""}>
                {paragraph}
              </p>
            ))}
          </div>
        </div>

        {/* Mission */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
           <div className="order-2 md:order-1 rounded-2xl overflow-hidden shadow-2xl h-full min-h-[400px]">
             <img 
               src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
               alt="Corporate Mission" 
               className="w-full h-full object-cover"
             />
           </div>
           <div className="order-1 md:order-2">
             <SectionTitle title={t.about.missionTitle} />
             <div className="prose prose-lg text-gray-600 space-y-4">
               {t.about.missionText.map((paragraph, idx) => (
                 <p key={idx}>{paragraph}</p>
               ))}
             </div>
           </div>
        </div>

      </div>
    </div>
  );
};

export default About;